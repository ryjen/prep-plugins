#! /bin/sh

aclocal \
&& automake --add-missing \
&& autoconf